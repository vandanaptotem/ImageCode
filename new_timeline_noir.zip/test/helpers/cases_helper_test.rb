require 'test_helper'

class CasesHelperTest < ActionView::TestCase
end
