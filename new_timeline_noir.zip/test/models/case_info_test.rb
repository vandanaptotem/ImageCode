require 'test_helper'

class CaseInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
