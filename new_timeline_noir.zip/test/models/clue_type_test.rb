require 'test_helper'

class ClueTypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
