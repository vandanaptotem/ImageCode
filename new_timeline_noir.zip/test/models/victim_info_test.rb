require 'test_helper'

class VictimInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
