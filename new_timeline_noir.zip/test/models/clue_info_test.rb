require 'test_helper'

class ClueInfoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
