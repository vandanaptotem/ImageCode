class AddCol < ActiveRecord::Migration
  def change
  end
end
