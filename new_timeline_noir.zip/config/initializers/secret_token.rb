# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
TimelineNoir::Application.config.secret_key_base = '9efb8e1d80951d6876a5d11c12127154063a59f30d371f5f61f2a2417c08110328e868ddb5a101af6d30090a423f9fe3acd89199b9fc392739a27eea320ae990'
