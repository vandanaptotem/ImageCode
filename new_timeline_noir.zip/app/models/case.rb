class Case < ActiveRecord::Base

end
