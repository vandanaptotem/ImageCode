/*
    TimelineJS - ver. 2.33.1 - 2014-06-24
    Copyright (c) 2012-2013 Northwestern University
    a project of the Northwestern University Knight Lab, originally created by Zach Wise
    https://github.com/NUKnightLab/TimelineJS
    This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
    If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/
/* Esperanto LANGUAGE 
================================================== */typeof VMM!="undefined"&&(VMM.Language={lang:"eo",api:{wikipedia:"eo"},date:{month:["januaro","februaro","marto","aprilo","majo","junio","julio","aŭgusto","septembro","oktobro","novembro","decembro"],month_abbr:["jan.","feb.","mar.","apr.","maj.","jun.","jul.","aŭg.","sep.","okt.","nov.","dec."],day:["dimanĉo","lundo","mardo","merkredo","ĵaŭdo","vendredo","sabato"],day_abbr:["dim.","lun.","mar.","mer.","ĵaŭ.","ven.","sab."]},dateformats:{year:"yyyy",month_short:"mmm",month:"mmmm yyyy",full_short:"d mmm",full:"d mmmm yyyy",time_short:"HH:MM:SS",time_no_seconds_short:"HH:MM",time_no_seconds_small_date:"HH:MM'<br/><small>'d mmmm yyyy'</small>'",full_long:"dddd',' d mmm yyyy 'ĉe' HH:MM",full_long_small_date:"HH:MM'<br/><small>'dddd',' d mmm yyyy'</small>'"},messages:{loading_timeline:"Ŝarĝante Kronologio... ",return_to_title:"Reveno al Titolo",expand_timeline:"Pliampleksigu Kronologio",contract_timeline:"Malpliampleksigu Kronologio",wikipedia:"El Vikipedio, la libera enciklopedio",loading_content:"Ŝarĝante enhavo",loading:"Ŝarĝante"}});